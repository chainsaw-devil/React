<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form method="post" action="checkLogin">
@csrf
  <center>
    <table>
        <tr>
            <td>UserName</td>
            <td> <input type="text" name="txtUsername" /> </td>
        </tr>

        <tr>
            <td>Password</td>
            <td> <input type="text" name="txtPassword" /> </td>
        </tr>

        <tr>
            <td></td>
            <td> <button type="submit" name="btnSubmit" value="Login">Login</button> </td>
        </tr>
    </table>
  </center>
</form>
</body>
</html>