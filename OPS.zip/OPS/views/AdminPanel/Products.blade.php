<?php
  session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel</title>
  <link rel="stylesheet" href="{{asset('/bootstrap/css/bootstrap.min.css')}}">
  <Script src="{{asset('/bootstrap/js/bootstrap.bundle.js')}}"></Script>
  <Script src="{{asset('/bootstrap/js/bootstrap.min.js')}}"></Script>
  <link rel="stylesheet" href="{{asset('/AdminPanel/sidebars.css')}}">
</head>
<body>

  <!-- Header -->
  @include('AdminPanel.AdminHeader')

  <div class="container-fluid">
    <div class="row ">
      <div class="col-lg-2 px-0">
      @include('AdminPanel.Sidebar')

      </div>
      <div class="container col-lg-10">
      <h4 class="p-2">Dashbord>Product</h4>
      <hr>
      <div>

        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Product Master</h5>
            <form method="POST" action="ProductCRUD" enctype="multipart/form-data" >
              @csrf
            <div class="row mb-3">
                <b><label class="col-sm-2 col-form-label" >Category Name</label></b>
                <div class="col-sm-12">
                  <input type="text" class="form-control" name="txtCategoryName" value="@isset($test) {{$test['CategoryName']}} @endisset">
                </div>
              </div>
              <div class="row mb-3">
                <b><label class="col-sm-2 col-form-label" >Sub Category Name</label></b>
                <div class="col-sm-12">
                  <input type="text" class="form-control" name="txtSubCategoryName" value="@isset($test) {{$test['SubCategoryName']}} @endisset">
                </div>
              </div>
              <div class="row mb-3">
                <b><label class="col-sm-2 col-form-label" >Product Name</label></b>
                <div class="col-sm-12">
                  <input type="text" class="form-control" name="txtProductName">
                </div>
                <div class="col-sm-12">
                  <input type="hidden" class="form-control" name="txtProductID" value="@isset($test) {{$test['ProductID']}} @endisset">
                </div>
              </div>
              <div class="row mb-3">
                <b><label class="col-sm-2 col-form-label" >MRP</label></b>
                <div class="col-sm-12">
                  <input type="text" class="form-control" name="txtMRP" value="@isset($test) {{$test['MRP']}} @endisset">
                </div>
              </div>
              <div class="row mb-3">
                <b><label class="col-sm-2 col-form-label" >GST</label></b>
                <div class="col-sm-12">
                  <input type="text" class="form-control" name="txtGST" value="@isset($test) {{$test['GST']}} @endisset">
                </div>
              </div>
              <div class="row mb-3">
                <b><label class="col-sm-2 col-form-label" >Net Amount</label></b>
                <div class="col-sm-12">
                  <input type="text" class="form-control" name="txtNetAmount" value="@isset($test) {{$test['NetAmount']}} @endisset">
                </div>
              </div>
              <div class="row mb-3">
                <b><label class="col-sm-2 col-form-label" >Remark</label></b>
                <div class="col-sm-12">
                  <input type="text" class="form-control" name="txtRemark" value="@isset($test) {{$test['Remark']}} @endisset">
                </div>
              </div>
              <div class="row mb-3">
                <b><label class="col-sm-2 col-form-label" >Product Image</label></b>
                <div class="col-sm-12">
                  <input type="file" class="form-control" name="txtProductImage" value="@isset($test) {{$test['ProductImage']}} @endisset">
                </div>
              </div>
             
              <button type="submit" name="ProductOperation" value="Insert" class="btn btn-success">Insert</button>
              <button type="submit" name="ProductOperation" value="Update" class="btn btn-primary">Update</button>
              <button type="Reset" name="ProductOperation" value="Reset" class="btn btn-primary">Reset</button>
            </form>
            <br>
           
              <table class="table table-striped table-hover">
                <tr>
                  <td class="fw-bold fs-5">CategoryName</td>
                  <td class="fw-bold fs-5">SubCategoryName</td>
                  <td class="fw-bold fs-5">ProductName</td>
                  <td class="fw-bold fs-5">MRP</td>
                  <td class="fw-bold fs-5">GST</td>
                  <td class="fw-bold fs-5">NetAmount</td>
                  <td class="fw-bold fs-5">Remark</td>
                  <td class="fw-bold fs-5">ProductImage</td>
                  <td class="fw-bold fs-5">Action</td>
                </tr>

              @isset($Data)
                 @foreach($Data as $d)
                   <tr>
                     <td>{{$d->CategoryName}}</td>
                     <td>{{$d->SubCategoryName}}</td>
                     <td>{{$d->ProductName}}</td>
                     <td>{{$d->MRP}}</td>
                     <td>{{$d->GST}}</td>
                     <td>{{$d->NetAmount}}</td>
                     <td>{{$d->Remark}}</td>
                     <td>
                      <img src="{{asset('/ProductImg/'.$d->ProductImage)}}" width="200px" height="200px">
                     </td>
                     <td>
                         <a type="submit" value="Edit" href="Edit/{{$d->ProductID}}" class="btn btn-success">Edit</a>
                         <a type="submit" value="Delete" href="Delete/{{$d->ProductID}}" class="btn btn-danger">Delete</a>
                    </td>
                  </tr>
                @endforeach 
              @endisset

              </table>
          </div>
        </div>
      </div>
      </div>
    </div>
  </div>
</body>
</html>