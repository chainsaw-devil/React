
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">   
    <title>Document</title>
    <link rel="stylesheet" href="{{asset('/bootstrap/css/bootstrap.min.css')}}">
  <Script src="{{asset('/bootstrap/js/bootstrap.bundle.js')}}"></Script>
  <Script src="{{asset('/bootstrap/js/bootstrap.min.js')}}"></Script>
    <link rel="stylesheet" href="{{asset('/bootstrap/Style.css')}}."> 

</head>
                 
<body>
    
    <section style="background-image:url(./Image/Plants/flower-729514_1280.jpg)">
        <div class="form-container">
        <div class="logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor"
            class="bi bi-people-fill" viewBox="0 0 16 16">
            <path
              d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H7Zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm-5.784 6A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216ZM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" />
          </svg>
        </div>
        <h1>Login From</h1>
        <?php
            session_start();
        ?>
        <!-- {{URL::to('CheckALogin')}} -->
    <form method="post" action="CheckALogin" >
        @csrf
        <div class="control">
        <input type="text" name="txtUsername" placeholder="USERNAME" value="@isset($_SESSION['UserName']) {{$_SESSION['UserName']}} @endisset" >
        </div>
        <br />
        <div class="control">
        <input type="password" name="txtPassword" placeholder="PASSWORD" value="@isset($_SESSION['Password']) {{$_SESSION['Password']}} @endisset" >
        </div>
        <br />
        <span><input type="checkbox"/>Remember me</span>

         <div class="control">
            <input type="submit" id="btnLogin" name="Login" value="SUBMIT" >

         </div>
    </form>
</div>
</section>

    <!-- <div class="container-fluid">
        <div class="card" style="width: 25%; ">
            <div class="card-body">
                <div class="row">
                    <div class="row-2">
                        <h3>LOGIN</h3>
                    </div>
                    <div class="row-4">
                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" id="floatingInput" placeholder="Username">
                            <label for="floatingInput">Username</label>
                        </div>
                        <div class="form-floating">
                            <input type="password" class="form-control" id="floatingPassword" placeholder="Password">
                            <label for="floatingPassword">Password</label>
                        </div><br>
                        <div>
                            <button type="button" class="btn btn-primary">LOGIN</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->
</body>

</html>