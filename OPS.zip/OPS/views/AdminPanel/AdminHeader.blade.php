<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel</title>
  <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
  <Script src="../bootstrap/js/bootstrap.bundle.js"></Script>
  <Script src="../bootstrap/js/bootstrap.min.js"></Script>
  <link rel="stylesheet" href="../AdminPanel/sidebars.css">
</head>

<body>

  <!-- Header -->

  <header class="p-3 text-bg-dark">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-2">
          <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
            <a href="/" class="text-white text-decoration-none">
              <!-- <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg> -->
              <h4>Admin Panel</h4>
            </a>
          </div>
          <div class="nav col-lg-10"></div>
        </div>
        <!-- <hr> -->
      </div>
    </div>
  </header>

</body>

</html>