<?php
// include "Dbcon.php";
session_start();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel</title>
  <link rel="stylesheet" href="{{asset('/bootstrap/css/bootstrap.min.css')}}">
  <Script src="{{asset('/bootstrap/js/bootstrap.bundle.js')}}"></Script>
  <Script src="{{asset('/bootstrap/js/bootstrap.min.js')}}"></Script>
  <link rel="stylesheet" href="{{asset('/AdminPanel/sidebars.css')}}">
</head>

<body>

  <!-- Header -->

    @include('AdminPanel.AdminHeader')

  <!-- Slidebar -->
  <div class="container-fluid">
    <div class="row ">
      <div class="col-lg-2 px-0">
          @include ('AdminPanel.Sidebar')
        <!-- <main class="d-flex flex-nowrap">
          <div class="text-bg-dark" style="width:100%; height:100vh; padding:none;">
            <div class="d-flex flex-column flex-shrink-0 ">
              <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                <svg class="bi pe-none me-2" width="40" height="32">
                  <use xlink:href="#bootstrap"></use>
                </svg>
                <span class="fs-4">OPS</span>
              </a>
              <hr>
              <ul class="nav nav-pills flex-column mb-auto">
                <li class="nav-item">
                  <a href="#" class="nav-link active" aria-current="page">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                      class="bi bi-house-fill" viewBox="0 0 16 16">
                      <path
                        d="M8.707 1.5a1 1 0 0 0-1.414 0L.646 8.146a.5.5 0 0 0 .708.708L8 2.207l6.646 6.647a.5.5 0 0 0 .708-.708L13 5.793V2.5a.5.5 0 0 0-.5-.5h-1a.5.5 0 0 0-.5.5v1.293L8.707 1.5Z" />
                      <path d="m8 3.293 6 6V13.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5V9.293l6-6Z" />
                    </svg>
                    Home
                  </a>
                </li>
                <li>
                  <a href="Category.php" class="nav-link text-white">
                    <svg class="bi pe-none me-2" width="16" height="16">
                      <use xlink:href="#table"></use>
                    </svg>
                    Category
                  </a>
                </li>
                <li>
                  <a href="#" class="nav-link text-white">
                    <svg class="bi pe-none me-2" width="16" height="16">
                      <use xlink:href="#table"></use>
                    </svg>
                    Sub Category
                  </a>
                </li>
                <li>
                  <a href="Product.php" class="nav-link text-white">
                    <svg class="bi pe-none me-2" width="16" height="16">
                      <use xlink:href="#grid"></use>
                    </svg>
                    Products
                  </a>
                </li>
                <li>
                  <a href="#" class="nav-link text-white">
                    <svg class="bi pe-none me-2" width="16" height="16">
                      <use xlink:href="#people-circle"></use>
                    </svg>
                    Customers Query
                  </a>
                </li>
              </ul>
              <hr>
              <div class="dropdown">
                <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle"
                  data-bs-toggle="dropdown" aria-expanded="true">
                  <img src="..." alt="" width="32" height="32" class="rounded-circle me-2">
                  <strong>mdo</strong>
                </a>
                <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                  <li><a class="dropdown-item" href="#">New project...</a></li>
                  <li><a class="dropdown-item" href="#">Settings</a></li>
                  <li><a class="dropdown-item" href="#">Profile</a></li>
                  <li>
                    <hr class="dropdown-divider">
                  </li>
                  <li><a class="dropdown-item" href="#">Sign out</a></li>
                </ul>
              </div>
            </div>

          </div>
        </main> -->
      </div>
      <div class="container col-lg-10">
        <h4 class="p-2">Dashbord</h4>
        <hr>
        <!-- Dashbord -->
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
        <div class="col">
            <div class="card shadow-sm">
              <!-- <svg class="bd-placeholder-img card-img-top" width="100%" height="225" xmlns="http://www.w3.org/2000/svg"
                role="img" aria-label="Placeholder: Thumbnail" preserveAspectRatio="xMidYMid slice" focusable="false">
                <title>Placeholder</title>
                <rect width="100%" height="100%" fill="#55595c"></rect><text x="50%" y="50%" fill="#eceeef"
                  dy=".3em">Thumbnail</text>
              </svg> -->
              <div class="card-body " style="background-image:linear-gradient(120deg,red,green);">
                
                <p class="card-text"><h3>Category</h3></p>
                <hr/>
                
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm" > 
              <div class="card-body" style="background-image:linear-gradient(120deg,pink,black);" >
              
                <p class="card-text"><h3>Sub Category</h3></p>
                <hr/>
                
              </div>
            </div>
          </div>
          <div class="col">
            <div class="card shadow-sm">
              <div class="card-body" style="background-image:linear-gradient(120deg,yellow,red);">
             
                <p class="card-text"><h3>Porduct</h3></p>
                <hr/>
                
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</body>

</html>