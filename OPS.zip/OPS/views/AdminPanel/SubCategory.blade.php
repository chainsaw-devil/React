<?php
  session_start();
 
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin Panel</title>
  <link rel="stylesheet" href="{{asset('/bootstrap/css/bootstrap.min.css')}}">
  <Script src="{{asset('/bootstrap/js/bootstrap.bundle.js')}}"></Script>
  <Script src="{{asset('/bootstrap/js/bootstrap.min.js')}}"></Script>
  <link rel="stylesheet" href="{{asset('/AdminPanel/sidebars.css')}}">
</head>

<body>
  <!-- Header -->
  @include('AdminPanel.AdminHeader')

  <div class="container-fluid">
    <div class="row ">
      <div class="col-lg-2 px-0">

      @include('AdminPanel.Sidebar')

      </div>
      <div class="container col-lg-10">
        <h4 class="p-2">Dashbord>Sub Category</h4>
        <hr>
        <div>
  
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Sub Category</h5>
              <form method="POST">
              <div class="row mb-3">
                  <b><label class="col-sm-2 col-form-label" >Category Name</label></b>
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="txtCategoryName" >
                  </div>
                </div>
                <div class="row mb-3">
                  <b><label class="col-sm-2 col-form-label" >SubCategory Name</label></b>
                  <div class="col-sm-12">
                    <input type="text" class="form-control" name="txtSubCategoryName">
                  </div>
                </div>
               
               
                <button type="submit" name="Insert" class="btn btn-success">Submit</button>
                <button type="submit" name="Update" class="btn btn-primary">Update</button>
                <button type="Reset" name="Reset" class="btn btn-primary">Reset</button>
              </form>
              <br>
              
            </div>
          </div>
      </div>
    </div>
  </div>
</body>
</html>