<?php
  session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Shoping Page</title>
  <link rel="stylesheet" href="{{asset('/bootstrap/css/bootstrap.min.css')}}">
  <Script src="{{asset('/bootstrap/js/bootstrap.bundle.js')}}"></Script>
  <Script src="{{asset('/bootstrap/js/bootstrap.min.js')}}"></Script>
  <!-- <link rel="stylesheet" href="../UserPanel/style.css"> -->
</head>

<body>
        @include('UserPanel.UserHeader')

<form method="POST">
 <div class="container-fluid mt-3">
  <div class="row">
  <!-- products -->
  @foreach($Data As $d)
      <div class="col-md-4 mb-3">
              <div class="card">
                <img class="card-img-top" src="{{asset('/ProductImg/'.$d->ProductImage)}}" style="height:100px width:100px" />
                  <div class="card-body">
                    <h5>{{$d->ProductName}}</h5>
                    <form method="POST">
                        <input type="hidden" name="hid" value="{{$d->ProductID}}">
                        <h4 class="card-title"></h4>
                        <input type="hidden" name="price" value="{{$d->NetAmount}}">
                        <p class="card-text"></p>
                        <input type="submit" value="AddtoCart" class="btn btn-primary" name="btnaddtocart">
                    </form>
                  <!-- <p class="card-text"><button type="button" class="btn btn-primary" name="btnaddtocart">Add to Cart</button></p> -->
                  </div>
              </div>
      </div>
    @endforeach  
  </div>
</div>
</form>
@include('UserPanel.UserFooter')
</body>

</html>