<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <Script src="./FET-Bootstrap/bootstrap-5.3.0-JS and CSS/js/bootstrap.bundle.min.js"></Script>
    <!-- <link rel="stylesheet" href="./style.css"> -->

</head>
<body>
<header class="p-3 text-bg-dark">
    <div class="container-fluid">
      <div class="d-flex flex-wrap align-items-center justify-content-center justify-content-lg-start">
        <a href="UserHome" class="d-flex align-items-center mb-1 mb-lg-0 text-white text-decoration-none">
          <img src="{{asset('/Image/Plants/amaryllis-1984899_1280.jpg')}}"  width="40" height="32" alt="">
          <strong class="p-2">Nursary Live</strong>
          <!-- <svg class="bi me-2" role="img" aria-label="Bootstrap"><use xlink:href="#bootstrap"></use></svg> -->
        </a>

        <ul class="nav col-12 col-lg-auto me-lg-auto mb-2 justify-content-center mb-md-0">
          <li><a href="UserHome" class="nav-link px-2 text-white">HOME</a></li>
          <li><a href="Shop" class="nav-link px-2 text-white">SHOP</a></li> 
          <li><a href="#" class="nav-link px-2 text-white">CONTACT US</a></li>
        </ul>

        <!-- <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
          <input type="search" class="form-control form-control-dark text-bg-dark" placeholder="Search..."  aria-label="Search">
        </form> -->

        <div class="text-end">
          <a  class="btn btn-outline-light me-2" href="UserLogin">Login</a>
          <a  class="btn btn-warning" href="SignUp">Sign-up</a>
          <a  class="btn btn-outline-light me-2" href="./Cart.php">
          <svg xmlns="http://www.w3.org/2000/svg" width="25" height="25" fill="currentColor" class="bi bi-cart2" viewBox="0 0 16 16">
              <path d="M0 2.5A.5.5 0 0 1 .5 2H2a.5.5 0 0 1 .485.379L2.89 4H14.5a.5.5 0 0 1 .485.621l-1.5 6A.5.5 0 0 1 13 11H4a.5.5 0 0 1-.485-.379L1.61 3H.5a.5.5 0 0 1-.5-.5zM3.14 5l1.25 5h8.22l1.25-5H3.14zM5 13a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0zm9-1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm-2 1a2 2 0 1 1 4 0 2 2 0 0 1-4 0z"/>
          </svg> Add to Cart
        </a>
        </div>
      </div>
    </div>
  </header>
</body>
</html>