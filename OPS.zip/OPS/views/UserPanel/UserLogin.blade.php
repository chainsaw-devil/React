<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Page</title>
  <link rel="stylesheet" href="{{asset('/bootstrap/css/bootstrap.min.css')}}">
  <Script src="{{asset('/bootstrap/js/bootstrap.bundle.js')}}"></Script>
  <Script src="{{asset('/bootstrap/js/bootstrap.min.js')}}"></Script>
  <link rel="stylesheet" href="../AdminPanel/Style.css">
  <link rel="stylesheet" href="{{asset('/bootstrap/Style.css')}}"> 
</head>

<body>
<section style="background-image:url({{asset('/Image/Plants/nature-3396254_640.jpg')}}">
        <div class="form-container">
        <div class="logo">
            <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="currentColor"
            class="bi bi-people-fill" viewBox="0 0 16 16">
            <path
              d="M7 14s-1 0-1-1 1-4 5-4 5 3 5 4-1 1-1 1H
              7Zm4-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6Zm-5.784 6A2.238 2.238 0 0 1 5 13c0-1.355.68-2.75 1.936-3.72A6.325 6.325 0 0 0 5 9c-4 0-5 3-5 4s1 1 1 1h4.216ZM4.5 8a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z" />
          </svg>
        </div>
        <h1>Login From</h1>
        <form method="POST" action="CheckULogin">
            @csrf
        <div class="control">
        <input type="text" name="txtUsername" placeholder="USERNAME" style="color: #fff;" >
        </div>
        <br />
        <div class="control">
        <input type="password" name="txtPassword" placeholder="PASSWORD" style="color: #fff;" >
        </div>
        <br />
       
         <div class="control">
            <input type="submit" id="btnLogin" name="submit" value="LOGIN" >
         </div>
         <br/>
         <span><a href="SignUp" class="mt-3">Sign Up</a></span>
    </form>
</div>
</section>
</body>
</html>