<?php

use Illuminate\Support\Facades\Route;
use App\http\Controllers\DBController;
// use App\http\Controllers\EmpController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

// Route::get('/demo', function () {
//     return view('demo').view('abc').view('demo');
// });

// Route::get('/abc', function () {
//     return view('abc');
// });

// ========================================Admin Routes=================================================

Route::get('/LoginMaster',function() {
    return view('AdminPanel.LoginMaster');
});

Route::get('/HomeAdmin',function() {
    return view('AdminPanel.HomeAdmin');
});

Route::get('/DashBoard',function() {
    return view('AdminPanel.DashBoard');
});

// Route::get('/Sidebar',function() {
//     return view('AdminPanel.Sidebar');
// });

// Route::get('/AdminHeader',function() {
//     return view('AdminPanel.AdminHeader');
// });

//--------------- Category Master---------------------------
Route::get('/Category',function() {
    return view('AdminPanel.Category');
});

Route::get('callCategory',[DBController::class,'callCategory']);
Route::Post('CategoryCRUD',[DBController::class,'CategoryCRUD']);
Route::get('Edit/{CategoryID}',[DBController::class,'FillCategory']);
Route::get('Delete/{CategoryID}',[DBController::class,'DeleteCategory']);

Route::get('/SubCategory',function() {
    return view('AdminPanel.SubCategory');
});

//--------------- Product Master---------------------------
Route::get('/Products',function() {
    return view('AdminPanel.Products');
});

Route::get('callProduct',[DBController::class,'callProduct']);
Route::Post('ProductCRUD',[DBController::class,'ProductCRUD']);
Route::get('Edit/{ProductID}',[DBController::class,'FillProduct']);
Route::get('Delete/{ProductID}',[DBController::class,'DeleteProduct']);


Route::post('CheckALogin',[DBController::class,'CheckALogin']);

// ========================================Admin Routes=================================================

Route::get('/UserLogin',function() {
    return view('UserPanel.UserLogin');
});

Route::get('/UserHome',function() {
    return view('UserPanel.UserHome');
});

Route::get('/Shop',function() {
    return view('UserPanel.Shop');
});

Route::get('Shop',[DBController::class,'ShopProduct']);


Route::post('CheckULogin',[DBController::class,'CheckULogin']);

// Route::Post('Empdata',[EmpController::class,'Empdata']);
