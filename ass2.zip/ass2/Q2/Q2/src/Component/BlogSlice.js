import { createSlice } from '@reduxjs/toolkit'
import axios from 'axios'

// const initialState = [
//     {
//         id: 1,
//         Title: "Pen",
//         Desc: "vmndhgfiudsahfuahiyfgf",
//         Likes: 10
//     },
//     {
//         id: 2,
//         Title: "Book",
//         Desc: "kfoiwejriuewffuahiyfgf",
//         Likes: 20
//     },
//     {
//         id: 3,
//         Title: "PQR",
//         Desc: "owieuifiudsahfuahiyfgf",
//         Likes: 40
//     }
// ]

export const BlogSlice = createSlice({
    name: "blog",
    initialState: {Blog:[],BlogType:[]} ,
    reducers: {
        // AddData: (state, action) => {
        //     // state.push({
        //     //     id: state.length+1,
        //     //     Title: action.payload.Title,
        //     //     Desc: action.payload.Desc,
        //     //     Likes: action.payload.Likes
        //     //})
        // }
        GetData:async(state,action)=>{
            //debugger;
            const res = await axios.get("http://localhost:1920/BlogMaster/DisplayBlog")
            //state.Blog=res.data;
            return {...state,Blog:res.data};
            //console.log(...state,Blog:res.data);
        },
        GetBlogType:async(state,action)=>{
            const res = await axios.get("http://localhost:1920/BlogMaster/GetBlogType")
            state.BlogType=res.data;
            return state;
        },
        GetBlogByType:async(state,action)=>{
            const res = await axios.get("http://localhost:1920/BlogMaster/GetBlogByType/"+action.payload)
            state.Blog=res.data;
            return state;
        },
        AddData:async(state,action)=>{
            const res = await axios.post("http://localhost:1920/BlogMaster/AddBlog",action.payload)
            state.Blog=res.data;
            return state;
        }
    }
})

export const{AddData,GetData,GetBlogType,GetBlogByType} = BlogSlice.actions
export default BlogSlice.reducer