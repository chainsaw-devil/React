import React, { useEffect } from 'react'
import { GetData, GetBlogByType, GetBlogType } from '../Component/BlogSlice';
import { useSelector, useDispatch } from 'react-redux'

const Home = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(GetData())
    dispatch(GetBlogType())
    console.log(Blogdata);
    console.log(BlogType);
  }, [])

  const Blogdata = useSelector((state) => state.blog.Blog);
  const BlogType = useSelector((state) => state.blog.BlogType);



  return (
    <div>
      <h1>Home Page</h1>
      <table>
        <tr>
          {
            BlogType.map(item => {
              return (
                <a onClick={() => dispatch(GetBlogByType({ item }))}><td>{item}</td></a>
              )
            })
          }
        </tr>
      </table>
      <div>
        {
          Blogdata.length > 0 && Blogdata.map(b => {
            return (
              <div class="card col-md-6">
                <div class="card-body ">
                  <h5 class="card-title">{b.BlogType}</h5>
                  <h6 class="card-subtitle mb-2 text-body-secondary">{b.Description}</h6>
                  <p class="card-text">{b.BlogName}</p>
                </div>
              </div>
            )
          })

        }
      </div>
    </div>

  )
}

export default Home
