import './App.css';
import NavBar from './Component/NavBar';
import { Routes,Route } from 'react-router';
import Home from './Pages/Home';
import Blog from './Pages/Blog';
import { useState } from 'react';

function App() {

  const [BlogData,setBlogData] = useState([

    {
      id:1,
      Title:"Pen",
      Desc:"vmndhgfiudsahfuahiyfgf",
      Likes:10
    },
    {
      id:2,
      Title:"Book",
      Desc:"kfoiwejriuewffuahiyfgf",
      Likes:20
    },
    {
      id:1,
      Title:"PQR",
      Desc:"owieuifiudsahfuahiyfgf",
      Likes:40
    }
  ]);
  return (
    <div className="App">
        <NavBar>
        </NavBar>
        <>
          <Routes>
            <Route path='/' element={<Home data={BlogData}/>} />
            <Route path='/addBlog' element={<Blog data={BlogData} setdata={setBlogData}/>} />
          </Routes>
        </>
    </div>
  );
}

export default App;
