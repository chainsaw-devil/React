const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const RegRoute = require("./Routes/Route");
const app = express();
app.use(express.json());
app.use(cors());
mongoose.connect('mongodb://127.0.0.1:27017/Registrationdb');
app.use('/RegForm',RegRoute);

app.listen('5051',()=>{

    console.log("Server Running");
    
})