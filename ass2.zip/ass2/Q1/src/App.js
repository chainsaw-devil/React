import './App.css';
import DisplayStudent from './Component/DisplayStudent';
import UpdateStudent from './Component/UpdateStudent';
import Form from './Component/Form';
import {Route,Routes} from 'react-router-dom';
import Navbar from './Component/Navbar';

function App() {
  return (
    <div className="App">
      <Navbar/>
      <Routes>
        <Route path='/' element={<Form/>}/>
        <Route path='/DisplayData' element={<DisplayStudent/>}/>
        <Route path='/UpdateStudent/:id' element={<UpdateStudent/>}/>
      </Routes>
    </div>
  );
}

export default App;
