import React, {useState} from 'react';
import axios from 'axios';
import {useNavigate} from 'react-router-dom';
import { useEffect } from 'react';

function Form()
{

    //let navigate = useNavigate();

    const[name,setName] = useState('');
    const[email,setEmail] = useState('');
    const[mobileno,setMobileNo] = useState('');
    const[address,setAddress] = useState('');
    const[dob,setDob] = useState('');
    const[city,setCity] = useState('');
    const[hobbies,sethobby] = useState('');

    const handleChangeName = (e) =>{
        setName(e.target.value);
    }
    const handleChangeEmail = (e) =>{

        setEmail(e.target.value);
    }
    const handleChangeMobileNo = (e) =>{
        setMobileNo(e.target.value);
    }
    const handleChangeAddress = (e) =>{
        setAddress(e.target.value);
    }
    const handleChangeDob = (e) =>{
        setDob(e.target.value);
    }
    const handleChangeCity = (e) =>{

        setCity(e.target.value);
    }
    const handleChangeHobby = (e) =>{
        var hob =[];
        e.target["h"].forEach(element => {
            if(element.checked)
              hob.push(element.value);
        });
        alert(hob.join(","));
        sethobby(sethobby);
    }

    const CollectData = async() => {
        // handleChangeHobby();
        alert(hobbies);

       

        try{
            let insertData = axios.post('http://localhost:5051/RegForm/RegRoute',{
                name,
                email,
                mobileno,
                address,
                dob,
                city,
                hobbies
            });

            if(insertData){

                //navigate('/',{replace:true});
            }
        }
        catch(error){
            console.log(error)
        }
    }

    return (
        <div>
            <form >
                <center><h1>Registration Form</h1></center>
                <center>
                <table>
                    <tr>
                        <td> <label>Name</label> </td>
                        <td> <input type='text' name='name' class="form-control" value={name} onChange={handleChangeName} ></input> </td>
                    </tr>
                    <tr>
                        <td> <label>EmailID</label> </td>
                        <td> <input type='email' name='email' class='form-control' value={email} onChange={handleChangeEmail} ></input> </td>
                    </tr>
                    <tr>
                        <td> <label>Mobileno</label> </td>
                        <td> <input type='text' name='mobileno' value={mobileno} onChange={handleChangeMobileNo} ></input> </td>
                    </tr>
                    <tr>
                        <td> <label>Address</label> </td>
                        {/* <td> <input type='text' name='address' value={address} onChange={handleChangeAddress} ></input> </td> */}
                        <td> <textarea type='text' name='address' value={address} onChange={handleChangeAddress} ></textarea> </td>
                    </tr>
                    <tr>
                        <td> <label>Dob</label> </td>
                        <td> <input type='date' name='dob' value={dob} onChange={handleChangeDob} ></input> </td>
                    </tr>
                    <tr>
                        <td> <label>City</label> </td>
                        {/* <td> <input type='text' name='city' value={city} onChange={handleChangeCity} ></input> </td> */}
                        <td> 
                            <select type='text' name='city' value={city} onChange={handleChangeCity}>
                                <option>Surat</option>
                                <option>Baruch</option>
                                <option>Vapi</option>
                                <option>Valsad</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <td> <label>Hobbies</label> </td>
                        {/* <td> <input type='text' name='city' value={city} onChange={handleChangeCity} ></input> </td> */}
                        <td> 
                           <div class="list-group">
                            {/* <label class="list-group-item"> */}
                              <input type="checkbox" name="h" value="Reading" onSelect={handleChangeHobby}/>
                              Reading
                            {/* </label> */}
                            {/* <label class="list-group-item"> */}
                              <input type="checkbox" name="h" value="Sports" onSelect={handleChangeHobby}/>
                              Sports
                            {/* </label>
                            <label class="list-group-item"> */}
                              <input type="checkbox" name="h" value="Travaling" onSelect={handleChangeHobby}/>
                              Travaling
                            {/* </label> */}
                             </div>
                        </td>
                    </tr>
                    <tr>
                        <td>  </td>
                        <td> <button onClick={CollectData} > Submit </button> </td>
                    </tr>
                </table>
                </center>
            </form>
        </div>
      )
}

export default Form
