import React from 'react'
import axios from 'axios';
import { useEffect,useState } from 'react';
import { NavLink } from 'react-router-dom';

const DisplayStudent = () => {

  const [data,setdata] = useState([]);

  useEffect(()=>{
    getdata();
  },[])

  const getdata = async() => {

    try{
        const res = await axios.get('http://localhost:5051/RegForm/DisplayStudRoute');

        console.log(res.data);
        setdata(res.data);
    }
    catch(err)
    {
        console.error(err);
    }

  }

  const deleteStud = async(id) => {
    try{
        let res = await axios.delete(`http://localhost:5051/RegForm/Delete/${id}`);
        if(res)
          getdata();
    }
    catch(err)
    {
        console.error(err);
    }

  }

  const StudRecord = data.map((data) =>{
    return(
        <tr>
          <td>{data.Name}</td>
          <td>{data.Email}</td>
          <td>{data.Mobileno}</td>
          <td>{data.Address}</td>
          <td>{data.Dob}</td>
          <td>{data.City}</td>
          <td>{data.Hobbies}</td>
          <td>
            <NavLink to={`/UpdateStudent/${data._id}`}>Edit</NavLink>
            <input type="Submit" value="delete" class="btn btn-danger" onClick={()=>deleteStud(data._id)}></input>
          </td>
        </tr>
    )
})
    
  return (
    <div>
       <table border={1} className='table table-striped'>
        <tr>
          <td>Name</td>
          <td>Email</td>
          <td>Mobileno</td>
          <td>Address</td>
          <td>Dob</td>
          <td>City</td>
          <td>Hobbies</td>
          <td>Action</td>
        </tr>
        {StudRecord}
       </table>
    </div>
  )
}

export default DisplayStudent
