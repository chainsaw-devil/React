import React, { useEffect } from 'react'
import { useState } from 'react'
import axios from 'axios'

const Bill = () => {

  const [Product, setProduct] = useState([])
  const [Data, setData] = useState([])
  const [Name, setName] = useState("");
  const [MobileNo, setMobileNo] = useState("");

  useEffect(() => {
    Filldata()
    FillBilldata()
  }, [])

  async function Filldata() {
    const res = await axios.get("http://localhost:1920/ProductMaster/DisplayProduct")
    var cnt = 1;
    var data = res.data.map(item => {
      return { ...item, qty: 0, id: cnt++ }
    })
    setProduct(data);
  }

  async function FillBilldata() {
    const res = await axios.get("http://localhost:1920/ProductMaster/DisplayBill")
    setData(res.data);
  }

  function SaveData() {
    var data = { Name, MobileNo, BillData: Product }
    const insert = axios.post("http://localhost:1920/BillMaster//AddBill", data)
    if (insert)
      alert('Inserted...')
  }
  // const [cntPizza, setcntPizza] = useState(0)
  // const [cntBurger, setcntBurger] = useState(0)

  function addQty(id) {
    var data = Product.map(item => {
      if (item.id == id) {
        item.qty += 1
      }
      return item
    })
    setProduct(data)
  }
  function subQty(id) {
    var data = Product.map(item => {
      if (item.id == id && item.qty > 0) {
        item.qty -= 1
      }
      return item
    })
    setProduct(data)
  }
  // function addBurgerQty() {
  //   setcntBurger(cntBurger + 1);
  // }
  // function subBurgerQty() {
  //   if (cntBurger > 0) {
  //     setcntBurger(cntBurger - 1);
  //   }
  // }
  return (
    <div>
      <h2>BILLING SYSTEM</h2><hr />
      {
        Product.map(item => {
          return (
            <div>
              <h2>{item.Name}</h2>
              <input type='button' value="-" onClick={() => subQty(item.id)}></input>
              {item.qty}
              <input type='button' value="+" onClick={() => addQty(item.id)}></input>
              <h3>{item.Name} Amount : {item.qty * +item.Price}</h3>
            </div>
          )
        })

      }
      <h3>{Product.length > 0 ? Product.reduce((a, b) => { return a + (+b.Price * b.qty) }, 0) : 0}</h3>
      <hr></hr>
      <label>Name</label>
      <input type='Text' onChange={event => setName(event.target.value)}></input>
      <br></br>
      <label>Address</label>
      <input type='Text' onChange={event => setMobileNo(event.target.value)}></input>
      <br></br>
      <input type='button' value="Save Data" onClick={() => SaveData()}></input>
      {/* <h2>Pizza Price(300)</h2>
        <input type='button' value="-" onClick={subPizzaQty}></input>
         {cntPizza}
        <input type='button' value="+" onClick={addPizzaQty}></input>
        <h3>Pizza Amount : {cntPizza*300}</h3>

        <h2>Burger Price(100)</h2>
        <input type='button' value="-" onClick={subBurgerQty}></input>
         {cntBurger}
        <input type='button' value="+" onClick={addBurgerQty}></input>
        <h3>Burger Amount : {cntBurger*100}</h3><hr/>

        <h3>Net Amount : {(cntPizza*300)+(cntBurger*100)}</h3> */}

      <table border={1}>
        <tr>
          {
            Data.map(item => {
              return (
                <div>
                  <td>{item.Name}</td>
                  <td>{item.MobileNo}</td>
                  <td><table>{item.BillData.map(bd => {
                    return (

                      <tr>
                        <td>{bd.Name}</td>
                        <td>{bd.Price}</td>
                        <td>{bd.qty}</td>
                        <td>{+bd.Price * bd.qty}</td>
                      </tr>

                    )
                  })}
                  <tr>
                      <td colSpan={3}>Total</td>
                      <td>{item.BillData.length > 0 ? item.BillData.reduce((a, b) => { return a + (+b.Price * b.qty) }, 0) : 0}</td>
                    </tr>
                  </table></td>
                </div>
              )
            })
          }
        </tr>
      </table>


    </div>


  )
}

export default Bill
