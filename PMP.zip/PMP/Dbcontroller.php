<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\emptbl;

class Dbcontroller extends Controller
{

    public function callemp()
    {
        $data=emptbl::all();
       // echo "Emp Click for get";
        // return view('Emp',["Name"=>"Raji"]);
        echo $data;
        return view('Emp',['Data'=>$data]);
    }

   public function Emp_Crud(Request $req)
    {
        if($req -> DBOperation == "Insert")
        {
            $emp = new emptbl();
            $emp->Name=$req->txtName ;
            $emp->MobileNo=$req->txtMobileNo ;
            $emp->Salary=$req->txtSalary ;

            $emp->save();
            return redirect('callemp');

        }
       
        // $name=$req->txtName ;
        // $mn=$req->txtMobileNo ;
        // $sal=$req->txtSalary ;
        // //return "click";
        // //dd($req->all());
        // return $req->input();
    }

    public function EditbyID($Empid) {
        $data1=emptbl::find($Empid);
        $data=emptbl::all();
        echo $data1;
        return view('Emp',['Data'=>$data,'alldata'=>$data1]);
    }
}
