
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Contact Us</title>
  <script src="{{asset('/bootstrap/color-modes.js')}}"></script>
  <link rel="stylesheet" href="{{asset('/bootstrap/css/bootstrap.min.css')}}">
  <script src="{{asset('/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
</head>

<body>
@include ('Client.Hearder')
  <main class="container mt-4">



  <div class="col-md-12">
      <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative">
        <div class="col p-4 d-flex flex-column position-static">
        <form class="row g-3" method="POST">
        <div class="col-md-12">
                <label for="inputEmail4" class="form-label">Name</label>
                <input type="text" class="form-control" id="inputEmail4" placeholder="Name" name="txtname">
              </div>
              <div class="col-md-12">
                <label for="inputEmail4" class="form-label">Faculty Name</label>
                <input type="text" class="form-control" id="inputEmail4" placeholder="Faculty Name" name="txtFname">
              </div>
              <div class="col-md-6">
                <label for="inputEmail4" class="form-label">Email</label>
                <input type="email" class="form-control" id="inputEmail4" placeholder="Email" name="txtEmail">
              </div>
              <div class="col-md-6">
                <label for="inputPassword4" class="form-label">EnrollMent No</label>
                <input type="Text" class="form-control" id="inputPassword4" placeholder="EnrollMent No" name="txtEN">
              </div>
              <div class="col-12">
                <label for="inputAddress" class="form-label">Query</label>
  <textarea class="form-control" id="exampleFormControlTextarea1" rows="3" placeholder="Query....." name="txtQuery"></textarea>
              </div>
              
              <div class="col-12">
                <button type="submit" class="btn btn-primary" name="bntsubmit">Send</button>
              </div>
            </form>
        </div>
        <div class="col-auto d-none d-lg-block">
          <img src="image/contact-us-1524408_640.webp" class="m-1 border" alt="">
        </div>
      </div>
    </div>
    </main>
</body>

</html>