<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

// use App\Models\LoginMaster;

class DBController extends Controller
{

    function CheckALogin(Request $req)
    {
        $id = $req->txtUsername;
        $pwd = $req->txtPassword;
        $flag=0;
        $data = DB::table('loginmaster')->get();

        foreach($data as $d)
        {
            if(strcmp($d->Username,$id)==0 && strcmp($d->Passward,$pwd)==0)
            {
                $flag=1;
                break;
            }
        }

        if($flag==1)
        {
            return redirect('DashBoard');
        }
        else{
            echo "<script> alert('Login Failed') </script>";
            // return redirect('LoginMaster');
        }

    }

    //----------------Category Master----------------------

    public function callCategory()
    {
        $data=DB::table('categorymaster')->get();
       // echo $data;
        return view('AdminPanel.Category',['Data'=>$data]);
    }

    public function FillCategory($CategoryID)
    {
        $data1=DB::table('categorymaster')->where("CategoryID",$CategoryID)->get();
        $d2 = @json_decode(json_encode($data1),true);
        $d3 = $d2[0];
        $data=DB::table('categorymaster')->get();
//        echo $data;
        return view('AdminPanel.Category',['Data'=>$data,'test'=>$d3]);
    }

    public function DeleteCategory($CategoryID)
    {
        $data1=DB::table('categorymaster')->where("CategoryID",$CategoryID)->delete();
//        echo $data;
        return redirect('callCategory');
    }

    public function CategoryCRUD(Request $req)
    {
        if($req -> CategoryOperation == "Insert")
        {
            $CategoryName=$req->txtCategoryName ;
           DB::table('categorymaster')->insert([
            "CategoryName"=>$CategoryName
           ]);
            return redirect('callCategory');
        }
        if($req -> CategoryOperation == "Update")
        {
            $CategoryID=$req->txtCategoryID;
            $CategoryName=$req->txtCategoryName;
           DB::table('categorymaster')->where("CategoryID",$CategoryID)->update([
            "CategoryName"=>$CategoryName
           ]);
            return redirect('callCategory');
        }
    }

    //-----------------------Product Master-----------------------------

    public function callProduct()
    {
        $data=DB::table('productmaster')->get();
       // echo $data;
        return view('AdminPanel.Products',['Data'=>$data]);
    }

    public function FillProduct($ProductID)
    {
        $data1=DB::table('productmaster')->where("ProductID",$ProductID)->get();
        $d2 = @json_decode(json_encode($data1),true);
        $d3 = $d2[0];
        $data=DB::table('productmaster')->get();
//        echo $data;
        return view('AdminPanel.Products',['Data'=>$data,'test'=>$d3]);
    }

    public function DeleteProduct($ProductID)
    {
        $data1=DB::table('productmaster')->where("ProductID",$ProductID)->delete();
//        echo $data;
        return redirect('callProduct');
    }

    public function ProductCRUD(Request $req)
    {
        if($req -> ProductOperation == "Insert")
        {
           $CategoryName=$req->txtCategoryName ;
           $SubCategoryName=$req->txtSubCategoryName ;
           $ProductName=$req->txtProductName ;
           $MRP=$req->txtMRP ;
           $GST=$req->txtGST ;
           $NetAmount=$req->txtNetAmount ;
           $Remark=$req->txtRemark ;
           $ProductImage=$req->txtProductImage ;
           
           $ext = $ProductImage->GetClientOriginalName();
           $newFileName = time().rand(1,100).'.'.$ext;
           $req-> txtProductImage->move(public_path('ProductImg'),$newFileName);
           
           DB::table('productmaster')->insert(
            ["CategoryName"=>$CategoryName,
            "SubCategoryName"=>$SubCategoryName,
            "ProductName"=>$ProductName,
            "MRP"=>$MRP,
            "GST"=>$GST,
            "NetAmount"=>$NetAmount,
            "Remark"=>$Remark,
            "ProductImage"=>$newFileName]
           );
            return redirect('callProduct');
        }
        if($req -> ProductOperation == "Update")
        {
            $ProductID=$req->txtProductID;
            $ProductName=$req->txtProductName;
           DB::table('productmaster')->where("ProductID",$ProductID)->update(
            ["CategoryName"=>$CategoryName],
            ["SubCategoryName"=>$SubCategoryName],
            ["ProductName"=>$ProductName],
            ["MRP"=>$MRP],
            ["GST"=>$GST],
            ["NetAmount"=>$NetAmount],
            ["Remark"=>$Remark],
            ["ProductImage"=>$ProductImage]
           );
            return redirect('callProduct');
        }
    }


//==========================================User Panel Controller========================================
    
function CheckULogin(Request $req)
{
    $id = $req->txtUsername;
    $pwd = $req->txtPassword;
    $flag=0;
    $data = DB::table('loginmaster')->get();

    foreach($data as $d)
    {
        if(strcmp($d->Username,$id)==0 && strcmp($d->Passward,$pwd)==0)
        {
            $flag=1;
            break;
        }
    }

    if($flag==1)
    {
        return redirect('UserHome');
    }
    else{
        echo "<script> alert('Login Failed') </script>";
        // return redirect('LoginMaster');
    }

}

    public function ShopProduct()
    {
        $data=DB::table('productmaster')->get();
       // echo $data;
        return view('UserPanel.Shop',['Data'=>$data]);
    }

    // function checkLogin(Request $req)
    //  {

    //     //echo "Method Call";
    //     $data=LoginMaster::all();
    //     $un=$req->txtUsername;
    //     $pwd=$req->txtPassword;

    //     foreach($data as $d)
    //     {
    //         if(strcmp($d['Username'],$un)==0 && strcmp($d['Passward'],$pwd)==0)
    //         {
    //             return view('/abc');
    //         }
    //     }
    //     return redirect('login');
    //  }
}
