<?php

use Illuminate\Support\Facades\Route;
use app\Http\Controller\abc;
use App\Http\Controllers\Dbcontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

//Login View
Route::get('/Login', function () {
    return view('Admin.Login');
});

//Dashboard View
Route::get('/Dashboard', function () {
    return view('Admin.Dashboard');
});


//Faculty View
Route::get('/Faculty', function () {
    return view('Admin.Faculty');
});

//StudentQuery View
Route::get('/StudentQuery', function () {
    return view('Admin.StudentQuery');
});

//ProjectAssing View
Route::get('/ProjectAssing', function () {
    return view('Admin.ProjectAssing');
});

//ApproveList View
Route::get('/ApproveList', function () {
    return view('Admin.ApproveList');
});

//NotApproveList View
Route::get('/NotApproveList', function () {
    return view('Admin.NotApproveList');
});


//Home Page View
Route::get('/Home', function () {
    return view('Client.Home');
});

//Contact Page View
Route::get('/Contact', function () {
    return view('Client.Contact');
});



