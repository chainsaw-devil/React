﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Student : System.Web.UI.Page
{
    MyWebService ws = new MyWebService();
    protected void Page_Load(object sender, EventArgs e)
    {
         DataSet ds = ws.StudentView();
         gvdata.DataSource = ds.Tables[0];
         gvdata.DataBind();

         ListAllClass();
         ListAllCourse();
    }

    public void ListAllClass()
    {
        DataSet ds = ws.ListAllClass();
        txtClass.DataSource = ds.Tables[0];
        txtClass.DataTextField = "ClassName";
        txtClass.DataValueField = "ClassID";
        txtClass.DataBind();
    }

    public void ListAllCourse()
    {
        DataSet ds = ws.ListAllCourse();
        txtCourse.DataSource = ds.Tables[0];
        txtCourse.DataTextField = "CourseName";
        txtCourse.DataValueField = "CourseID";
        txtCourse.DataBind();
    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
       // MyWebService ws = new MyWebService();
        string s = ws.StudentInsert(Convert.ToInt32(txtRollNo.Text), txtName.Text, txtClass.SelectedValue, txtCourse.SelectedValue, txtEmailID.Text, txtMobileNo.Text, Convert.ToDateTime(txtDOB.Text));
        Response.Write(" <script>alert('"+s+"')</script>");
    }
}