﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for MyWebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class MyWebService : System.Web.Services.WebService {

    SqlConnection con = new SqlConnection("Data Source=VIDHI;Initial Catalog=Studentdb;User ID=sa;Password=sqlserver");
    public MyWebService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }

    [WebMethod]
    public string StudentInsert(Int32 RollNo, string Name, string ClassID, string CourseID, string Email, string Mobile, DateTime Dob )
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("StudentInsert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@RollNo",RollNo).DbType = DbType.Int32;
            cmd.Parameters.AddWithValue("@Name",Name).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@Class",ClassID).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@Course",CourseID).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@Email",Email).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@Mobile",Mobile).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@Dob",Dob).DbType = DbType.Date;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            return "Inserted";

        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        finally {
            con.Close();
        }
    }

    [WebMethod]
    public DataSet StudentView()
    {
            con.Open();
            SqlCommand cmd = new SqlCommand("StudentGet", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            return ds;

    }

    [WebMethod]
    public DataSet ListAllClass()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("ListAllClass", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        return ds;

    }

    [WebMethod]
    public DataSet ListAllCourse()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("ListAllCourse", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        return ds;

    }
    
}
