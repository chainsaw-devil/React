﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using Q3.Models;

namespace Q3.Controllers
{
    public class EmployeeController : Controller
    {
        private DBCon db = new DBCon();        

        // GET: Employee
        //public ActionResult Index()
        //{
        //    return View(db.EmployeeMasters.Include(des => des.DesignationMaster).Include(dept => dept.DepartmentMaster).ToList());
        //}

        //GET: Employee
        public ActionResult Index(decimal? Salary)
        {
            ViewData["Salary"] = Salary;
            if (Salary != null)
                return View(db.EmployeeMasters.Where(e => e.Salary > Salary).Include(des => des.DesignationMaster).Include(dept => dept.DepartmentMaster).ToList());
            else
                return View(db.EmployeeMasters.Include(des => des.DesignationMaster).Include(dept => dept.DepartmentMaster).ToList());

        }

        public ActionResult EmployeeDepartmentBag()
        {
            ViewBag.DepartmentList = db.DepartmentMasters.ToList();
            return View();
        }

        // GET: Employee/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeMaster employeeMaster = db.EmployeeMasters.Find(id);
            if (employeeMaster == null)
            {
                return HttpNotFound();
            }
            return View(employeeMaster);
        }

        // GET: Employee/Create
        public ActionResult Create()
        {
            //List<SelectListItem> departmentList = new List<SelectListItem>();
            //foreach (var Deparment in db.DepartmentMasters.ToList())
            //{
            //    departmentList.Add(new SelectListItem
            //    {
            //        Value = Deparment.DepartmentID.ToString(),
            //        Text = Deparment.DepartmentName
            //    });
            //}
            //ViewBag.DepartmentDropdownList = departmentList;

            ViewBag.DepartmentDropdownList = new SelectList(db.DepartmentMasters, "DepartmentID", "DepartmentName");
            ViewBag.DesignationDropdownList = new SelectList(db.DesignationMasters, "DesignationID", "DesignationName");
            return View();
        }

        // POST: Employee/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "EmployeeNo,EmployeeName,DOB,DesignationID,DepartmentID,Salary,CV")] EmployeeMaster employeeMaster)
        {
            if (ModelState.IsValid)
            {
                db.EmployeeMasters.Add(employeeMaster);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(employeeMaster);
        }

        // GET: Employee/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeMaster employeeMaster = db.EmployeeMasters.Find(id);
            if (employeeMaster == null)
            {
                return HttpNotFound();
            }

            ViewBag.DepartmentDropdownList = new SelectList(db.DepartmentMasters, "DepartmentID", "DepartmentName");
            ViewBag.DesignationDropdownList = new SelectList(db.DesignationMasters, "DesignationID", "DesignationName");
            return View(employeeMaster);
        }

        // POST: Employee/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "EmployeeNo,EmployeeName,DOB,DesignationID,DepartmentID,Salary,CV")] EmployeeMaster employeeMaster)
        {
            if (ModelState.IsValid)
            {
                db.Entry(employeeMaster).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(employeeMaster);
        }

        // GET: Employee/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            EmployeeMaster employeeMaster = db.EmployeeMasters.Find(id);
            if (employeeMaster == null)
            {
                return HttpNotFound();
            }
            return View(employeeMaster);
        }

        // POST: Employee/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            EmployeeMaster employeeMaster = db.EmployeeMasters.Find(id);
            db.EmployeeMasters.Remove(employeeMaster);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
                
        public ActionResult DeleteAge()
        {
            var employees = db.EmployeeMasters.Where(emp => (DateTime.Now.Year - emp.DOB.Value.Year) > 58);
            db.EmployeeMasters.RemoveRange(employees);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
