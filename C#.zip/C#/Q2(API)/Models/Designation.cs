﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebAPI.Models
{
    public class Designation
    {
        public int DesgId { get; set; }
        public string DesgName { get; set; }

        public List<Designation> getDesig()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            List<Designation> designation = new List<Designation>();

            try
            {
                //using (SqlCommand cmd = new SqlCommand("Select * From Designation", con))
                using (SqlCommand cmd = new SqlCommand("DesignationList", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        Designation d = new Designation();
                        d.DesgId = Convert.ToInt32(dr[0].ToString());
                        d.DesgName = dr[1].ToString();

                        designation.Add(d);
                    }
                    con.Close();
                }
            }
            catch (Exception ex)
            {

            }
            return designation;
        }
    }
}