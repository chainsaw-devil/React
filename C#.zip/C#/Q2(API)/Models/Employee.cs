﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebAPI.Models
{
    public class Employee
    {
        public int Eno { get; set; }
        public string Name { get; set; }
        public DateTime DOB { get; set; }
        public int Designation { get; set; }
        public int Department { get; set; }
        public string Salary { get; set; }
        public string CV { get; set; }

        public string DepartmentName { get; set; }
        public string DesignationName { get; set; }

        public void UpdateEmp(int id)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            try
            {
                using(SqlCommand cmd=new SqlCommand("EmpUpdate", con))
                {
                    con.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Eno", id).DbType = DbType.Int32;
                    cmd.Parameters.AddWithValue("@Name", this.Name).DbType = DbType.String;
                    cmd.Parameters.AddWithValue("@DOB", this.DOB).DbType = DbType.Date;
                    cmd.Parameters.AddWithValue("@Designation", this.Designation).DbType = DbType.Int32;
                    cmd.Parameters.AddWithValue("@Dept", this.Department).DbType = DbType.Int32;
                    cmd.Parameters.AddWithValue("@Salary", this.Salary).DbType = DbType.String;
                    cmd.Parameters.AddWithValue("@CV", this.CV).DbType = DbType.String;
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            catch(Exception ex)
            {
            }
        }

        public int insertEmp()
        {
            int i = 0;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            try
            {
                using (SqlCommand cmd = new SqlCommand("EmployeeInsert", con))
                {
                    con.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Name", this.Name).DbType = DbType.String;
                    cmd.Parameters.AddWithValue("@DOB", this.DOB).DbType = DbType.Date;
                    cmd.Parameters.AddWithValue("@Designation", this.Designation).DbType = DbType.Int32;
                    cmd.Parameters.AddWithValue("@Dept", this.Department).DbType = DbType.Int32;
                    cmd.Parameters.AddWithValue("@Salary", this.Salary).DbType = DbType.String;
                    cmd.Parameters.AddWithValue("@CV", this.CV).DbType = DbType.String;
                    i = cmd.ExecuteNonQuery();
                    cmd.Dispose();
                    con.Close();
                }
            }
            catch(Exception ex)
            {

            }
            return i;
        }

        public List<Employee> getEmp()
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            List<Employee> emplist = new List<Employee>();

            try
            {
                using (SqlCommand cmd = new SqlCommand("EmployeeList", con))
                //using (SqlCommand cmd = new SqlCommand("Select e.Eno, e.Name, e.DOB, desig.DesgName, dept.DeptName, e.Salary, e.CV From ((Employee e INNER JOIN Department dept ON e.Dept = dept.DeptId) INNER JOIN Designation desig ON e.Designation = desig.DesgId);", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        Employee e = new Employee();
                        e.Eno = Convert.ToInt32(dr[0].ToString());
                        e.Name = dr[1].ToString();
                        e.DOB = Convert.ToDateTime(dr[2].ToString());
                        e.Designation = Convert.ToInt32(dr[3].ToString());
                        e.Department = Convert.ToInt32(dr[4].ToString());
                        e.Salary = dr[5].ToString();
                        e.CV = dr[6].ToString();
                        e.DepartmentName = dr[7].ToString();
                        e.DesignationName = dr[8].ToString();

                        emplist.Add(e);
                    }
                    con.Close();
                }
            }
            catch(Exception ex)
            {
                //return ex.ToString();
            }
            return emplist;
        }

        public Employee getEmpId(int id)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);
            Employee e = new Employee();

            try
            {
                using (SqlCommand cmd = new SqlCommand("Select * From Employee Where Eno ="+ id, con))
                {
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();

                    while (dr.Read())
                    {
                        e.Eno = Convert.ToInt32(dr[0].ToString());
                        e.Name = dr[1].ToString();
                        e.DOB = Convert.ToDateTime(dr[2].ToString());
                        e.Designation = Convert.ToInt32(dr[3].ToString());
                        e.Department = Convert.ToInt32(dr[4].ToString());
                        e.Salary = dr[5].ToString();
                        e.CV = dr[6].ToString();

                    }
                    con.Close();
                }
            }
            catch (Exception ex)
            {
                //return ex.ToString();
            }
            return e;
        }
    }
}