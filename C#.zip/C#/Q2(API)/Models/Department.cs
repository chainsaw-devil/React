﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace WebAPI.Models
{
    public class Department
    {
        public int DeptId { get; set; }
        public string DeptName { get; set; }

        public List<Department> getDept()
        {
            List<Department> depts = new List<Department>();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con"].ConnectionString);

            try
            {
                using (SqlCommand cmd = new SqlCommand("DepartmentList", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        Department dept = new Department();
                        dept.DeptId = Convert.ToInt32(dr[0].ToString());
                        dept.DeptName = dr[1].ToString();

                        depts.Add(dept);
                    }
                    con.Close();
                }
            }
            catch(Exception ex)
            {
                
            }
            return depts;
        }
    }
}