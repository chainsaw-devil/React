﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI.Models;

namespace WebAPI.Controllers
{
    public class EmployeeController : ApiController
    {
        // GET: api/Employee
        public IEnumerable<Employee> Get()
        {
            return new Employee().getEmp();
            //return new string[] { "value1", "value2" };
        }

        // GET: api/Employee/5
        public Employee Get(int id)
        {
            return new Employee().getEmpId(id);
        }

        // POST: api/Employee
        public void Post([FromBody]Employee e)
        {
            int i = e.insertEmp();
        }

        // PUT: api/Employee/5
        public void Put(int id, [FromBody]Employee e)
        {
            e.UpdateEmp(id);
        }

        // DELETE: api/Employee/5
        public void Delete(int id)
        {
        }
    }
}
