﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Newtonsoft.Json;

public partial class Employee : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getdept();
            getdesig();
            getEmp();
        }
    }

    public void getdept()
    {
        try
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage msg = client.GetAsync("http://localhost:57619/api/Department").Result;

            if (msg.IsSuccessStatusCode)
            {
                string data = msg.Content.ReadAsStringAsync().Result;
                List<Department> deptlist = JsonConvert.DeserializeObject<List<Department>>(data);
                ddlDept.DataSource = deptlist;
                ddlDept.DataTextField = "DeptName";
                ddlDept.DataValueField = "DeptId";
                ddlDept.DataBind();

                //[{"DeptId":0,"DeptName":"-- Select Department --"},{"DeptId":1,"DeptName":"HR"},{"DeptId":2,"DeptName":"Sales"},{"DeptId":3,"DeptName":"Marketing"}]
                //Response.Write(data);
            }
        }
        catch(Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    public void getdesig()
    {
        try
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage msg = client.GetAsync("http://localhost:57619/api/Designation").Result;

            if (msg.IsSuccessStatusCode)
            {
                string data = msg.Content.ReadAsStringAsync().Result;
                List<Designation> desg = JsonConvert.DeserializeObject<List<Designation>>(data);
                ddlDesig.DataSource = desg;
                ddlDesig.DataTextField = "DesgName";
                ddlDesig.DataValueField = "DesgId";
                ddlDesig.DataBind();
            }
        }
        catch(Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    public void getEmp()
    {
        try
        {
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage msg = client.GetAsync("http://localhost:57619/api/Employee").Result;

            if (msg.IsSuccessStatusCode)
            {
                string data = msg.Content.ReadAsStringAsync().Result;
                List<Employees> emp = JsonConvert.DeserializeObject<List<Employees>>(data);
                gvData.DataSource = emp;
                gvData.DataBind();
            }
        }
        catch(Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void btnEdit_Click(object sender, EventArgs e)
    {
        try
        {
            //get the button which is clicked
            Button btn = (Button)sender;
            //get that button row from gridview
            GridViewRow gvr = (GridViewRow)btn.Parent.NamingContainer;
            hfEno.Value = (gvData.DataKeys[gvr.RowIndex].Values["Eno"]).ToString();
            //Response.Write(hfEno.Value);

            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            HttpResponseMessage msg = client.GetAsync("http://localhost:57619/api/Employee?id="+ hfEno.Value).Result;

            if (msg.IsSuccessStatusCode)
            {
                string data = msg.Content.ReadAsStringAsync().Result;
                Employees emp = JsonConvert.DeserializeObject<Employees>(data);
                txtname.Text = emp.Name;
                txtdob.Text = emp.DOB.ToString("yyyy-mm-dd");
                txtsal.Text = emp.Salary;
                ddlDept.SelectedValue = emp.Department.ToString();
                ddlDesig.SelectedValue = emp.Designation.ToString();
            }
        }
        catch(Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void btnDelete_Click(object sender, EventArgs e)
    {

    }

    protected void btnSave_Click(object sender, EventArgs e)
    {
        try
        {
            if (hfEno.Value == "")
            {
                string path = "";
                if (fuCV.HasFile)
                {
                    path = "CV/" + DateTime.Now.ToString("yyyyMMdd") + fuCV.FileName;
                    fuCV.SaveAs(Server.MapPath("~/" + path));

                    Employees emp = new Employees();
                    emp.Name = txtname.Text;
                    emp.Designation = Convert.ToInt32(ddlDesig.SelectedValue);
                    emp.Department = Convert.ToInt32(ddlDept.SelectedValue);
                    DateTime date = DateTime.Parse(txtdob.Text);
                    emp.DOB = date;
                    emp.Salary = txtsal.Text;
                    emp.CV = path;

                    HttpClient client = new HttpClient();
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    string p = JsonConvert.SerializeObject(emp);
                    Response.Write(p);
                    StringContent sc = new StringContent(p, Encoding.UTF8, "application/json");

                    client.PostAsync("http://localhost:57619/api/Employee", sc);
                    
                }
                else
                {
                    Response.Write("Please Select PDF File..!!");
                }
                getEmp();
            }
            else
            {
                string path = "";
                if (fuCV.HasFile)
                {
                    path = "CV/" + DateTime.Now.ToString("yyyyMMdd") + fuCV.FileName;
                    fuCV.SaveAs(Server.MapPath("~/" + path));
                }
                Employees emp = new Employees();
                emp.Name = txtname.Text;
                emp.Designation = Convert.ToInt32(ddlDesig.SelectedValue);
                emp.Department = Convert.ToInt32(ddlDept.SelectedValue);
                DateTime date = DateTime.Parse(txtdob.Text);
                emp.DOB = date;
                emp.Salary = txtsal.Text;
                emp.CV = path;

                HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                string p = JsonConvert.SerializeObject(emp);
                //Response.Write(p);
                StringContent sc = new StringContent(p, Encoding.UTF8, "application/json");

                client.PutAsync("http://localhost:57619/api/Employee?id="+hfEno.Value, sc);
                
            }
            getEmp();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }
}