﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for MyWebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class MyWebService : System.Web.Services.WebService {

    SqlConnection con = new SqlConnection("Data Source=VIDHI;Initial Catalog=Studentdb;User ID=sa;Password=sqlserver");
    public MyWebService () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string HelloWorld() {
        return "Hello World";
    }

    [WebMethod]
    public string EmpInsert(string Name, DateTime Dob ,string DesgID, string DeptID, string Salary, string CV)
    {
        try
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("EmpInsert", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Name",Name).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@Dob",Dob).DbType = DbType.Date;
            cmd.Parameters.AddWithValue("@DesgID",DesgID).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@DeptID",DeptID).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@Salary",Salary).DbType = DbType.String;
            cmd.Parameters.AddWithValue("@CV",CV).DbType = DbType.String;
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            con.Close();
            return "Inserted";

        }
        catch (Exception ex)
        {
            return ex.Message;
        }
        finally {
            con.Close();
        }
    }

    [WebMethod]
    public DataSet EmpView()
    {
            con.Open();
            SqlCommand cmd = new SqlCommand("EmpGet", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            return ds;

    }

    [WebMethod]
    public DataSet ListAllDepartment()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("ListAllDepartment", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        return ds;

    }

    [WebMethod]
    public DataSet ListAllDesignation()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("ListAllDesignation", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        return ds;

    }

    [WebMethod]
    public DataSet EmpGetByDesignation()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("EmpGetByDesignation", con);
        cmd.CommandType = CommandType.StoredProcedure;
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        con.Close();
        return ds;

    }
    
}
