﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Student : System.Web.UI.Page
{
    MyWebService ws = new MyWebService();
    protected void Page_Load(object sender, EventArgs e)
    {
         DataSet ds = ws.EmpView();
         gvdata.DataSource = ds.Tables[0];
         gvdata.DataBind();

         ListAllDesignation();
         ListAllCourse();
    }

    public void ListAllDesignation()
    {
        DataSet ds = ws.ListAllClass();
        txtDesignation.DataSource = ds.Tables[0];
        txtDesignation.DataTextField = "DesignationName";
        txtDesignation.DataValueField = "DesignationID";
        txtDesignation.DataBind();
    }

    public void ListAllDepartment()
    {
        DataSet ds = ws.ListAllDepartment();
        txtDepartment.DataSource = ds.Tables[0];
        txtDepartment.DataTextField = "DepartmentName";
        txtDepartment.DataValueField = "DepartmentID";
        txtDepartment.DataBind();
    }

    protected void btnInsert_Click(object sender, EventArgs e)
    {
       // MyWebService ws = new MyWebService();
       string ext = System.IO.Path.GetExtension(txtFile.FileName);
            if (ext == ".PDF" || ext == ".pdf")
            {
                string strguid = Guid.NewGuid().ToString();
                string savefilename = Server.MapPath("CVImage/")  + strguid + ext;
                string strname = "CVImage/" + strguid + ext;
                txtFile.SaveAs(savefilename);
                string s = ws.EmpInsert(txtName.Text,  Convert.ToDateTime(txtDOB.Text),txtDepartment.SelectedValue, txtDesignation.SelectedValue, txtSalary.Text, strname);
                Response.Write("<script>alert('"+s+"')</script>");
            }
    }
}